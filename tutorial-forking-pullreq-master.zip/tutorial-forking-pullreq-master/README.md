# tutorial-forking-pullreq contains the files for a brief tutorial on how to fork and initiate a pull-request in GitHub.
## There are two markdown files in this repository;
- "Tutorial-fork-pullreq.md" is the tutorial page itself
- "Assignment-file-HydraNotes.md" is a preformatted page for students to edit collaboratively in the exercise
